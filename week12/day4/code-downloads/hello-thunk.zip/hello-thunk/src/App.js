import logo from './logo.svg';
import './App.css';
import MovieList from './components/MovieList';
import Login from './components/Login';

function App() {
  return (
    <div>
       <MovieList />
      <Login />
    </div>
   
  );
}

export default App;
