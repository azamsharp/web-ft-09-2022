import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { createStore, applyMiddleware, compose } from 'redux'
import reducer from './store/reducer';
import { Provider } from 'react-redux'
import thunk from 'redux-thunk'
import BaseLayout from './components/BaseLayout';
import { Router, Route, Switch } from 'react-router-dom'
import Dashboard from './components/Dashboard';
import history from './utils/history'

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

// middleware lies between when the action is dispatched and before it reaches the reducer 

const store = createStore(reducer, composeEnhancers(
  applyMiddleware(thunk) // redux-thunk middleware
))

ReactDOM.render(
  <React.StrictMode>
    <Provider store = {store}>
      <Router history = {history}>
      <BaseLayout>
      <Switch>
        <Route exact path = "/" component = {App} />
        <Route exact path = "/dashboard" component = {Dashboard} />
      </Switch>
      </BaseLayout>
      </Router>
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
