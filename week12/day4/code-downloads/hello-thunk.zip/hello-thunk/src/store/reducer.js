
const initialState = {
    movies: [],
    isAuthenticated: null 
}

const reducer = (state = initialState, action) => {

    switch (action.type) {
        case 'MOVIES_LOADED':
            return {
                ...state,
                movies: action.payload
            }
        case 'ON_LOGIN':
            return {
                ...state,
                isAuthenticated: action.payload
            }
        default:
            return state
    }
}

export default reducer