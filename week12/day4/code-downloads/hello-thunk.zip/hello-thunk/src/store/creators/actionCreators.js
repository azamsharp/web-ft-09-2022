import * as actionTypes from '../actions/actionTypes'
import history from '../../utils/history'

export const loadMovies = () => {

    return (dispatch) => {

        fetch('https://mirror-vivid-foe.glitch.me/movies')
            .then(response => response.json())
            .then(movies => {
                dispatch({type: actionTypes.MOVIES_LOADED, payload: movies})
            })
    }

}

export const login = (credentials) => {
    return (dispatch) => {

        fetch('https://mirror-vivid-foe.glitch.me/login', {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json'
            }, 
            body: JSON.stringify(credentials)
        }).then(response => response.json())
        .then(result => {
            dispatch({type: 'ON_LOGIN', payload: result.success})
            // if user is logged in successfully then take user to dashboard page 
            if(result.success) {
                history.push('/dashboard')
            }
        })

    }
}