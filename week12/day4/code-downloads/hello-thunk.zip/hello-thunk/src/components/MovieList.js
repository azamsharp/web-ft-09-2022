
import { useEffect } from 'react'
import { connect } from 'react-redux'
import * as actionCreators from '../store/creators/actionCreators'

function MovieList(props) {

    useEffect(() => {
       props.onLoadMovies()
    })

    return (
        <h1>MovieList</h1>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onLoadMovies: () => dispatch(actionCreators.loadMovies())
    }
}

export default connect(null, mapDispatchToProps)(MovieList)