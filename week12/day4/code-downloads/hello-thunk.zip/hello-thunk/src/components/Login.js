
import { useState } from 'react'
import { connect } from 'react-redux'
import * as actionCreators from '../store/creators/actionCreators'

function Login(props) {

    const [credentials, setCredentials] = useState({})

    const handleChange = (e) => {
        setCredentials({
            ...credentials, 
            [e.target.name]: e.target.value
        })
    }

    const isLoggedIn = () => {
        return (props.isLoggedIn != null && props.isLoggedIn == false) 
    }

    const handleLogin = () => {
        props.onLogin(credentials)
    }

    return (
        <div>
            <input type="text" onChange = {handleChange} name = "username" />
            <input type="text" onChange = {handleChange} name = "password" />
            <button onClick = {handleLogin}>Login</button>
            {isLoggedIn() ? <div>Incorrect username or password</div> : null}
        </div>
    )
}

const mapDispatchToProps = (dispatch) => {
    return {
        onLogin: (credentials) => dispatch(actionCreators.login(credentials))
    }
}

const mapStateToProps = (state) => {
    return {
        isLoggedIn: state.isAuthenticated
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Login) 