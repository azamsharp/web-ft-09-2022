

import { connect } from 'react-redux'
import { NavLink } from 'react-router-dom'

function Menu(props) {

    return (
        <div>
            <div><NavLink to = "/">Home</NavLink></div>
           {props.isAuth ?  <NavLink to = "/movies">Movies</NavLink> : null } 
            
            { !props.isAuth ? <div>Register</div> : null }
            { !props.isAuth ? <div>Login</div> : null }
            { props.isAuth ? <div>Profile</div> : null }
            { props.isAuth ? <div>Logout</div> : null }
        </div>
    )
}

const mapStateToProps = (state) => {
    return {
        isAuth: state.isAuthenticated 
    }
}

export default connect(mapStateToProps)(Menu)