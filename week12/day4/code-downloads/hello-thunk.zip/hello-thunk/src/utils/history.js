

import createHistory from 'history/createHashHistory'
export default createHistory()